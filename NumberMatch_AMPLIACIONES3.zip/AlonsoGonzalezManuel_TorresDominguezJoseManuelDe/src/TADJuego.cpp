//============================================================================
// Name        : TADJuego.cpp
// Author      : Manuel Alonso González y José Manuel de Torres Domínguez
// Version     : Ampliación 3.
// Copyright   : JMDTDMAG (C) 2023
// Description : TAD Juego
//============================================================================

#include "TADJuego.h"

bool iniciarPartida(partida &p) {
	/*
	 * SECUENCIA DE ARRANQUE: CARGAR ARCHIVOS
	 */
	int filas, columnas, iniciales, replicas, ayudas, random;
	int m[MAX_FILAS][MAX_COLUMNAS];
	bool cargado;
	tablero t;
	int i, j;

	//Cargamos la configuración a las variables.
	if (entornoCargarConfiguracion(filas, columnas, iniciales, replicas, ayudas, random, m)) {
		p.replicas = replicas;
		p.ayudas = ayudas;
		p.puntuacion = 0;

		if (random != 0) {
			//Si el tablero es random...
			crearTablero(t, filas, columnas, iniciales);
			//Crear un tablero random
		} else {
			//Si el tablero NO es random...
			crearTablero(t, filas, columnas, iniciales);
			//creamos un tablero random, y reemplazamos los números a partir del archivo de configuración.
			for (i = 0; i < iniciales; i++) {
				for (j = 0; j < columnas; j++) {
					ponerNumCelda(t, i, j, m[i][j]);
				}
			}
		}

		p.t = t;

		cargado = true;
	} else {
		cout
				<< "Se ha producido un error en la carga del archivo match.cfg (¿no se encuentra en el directorio de ejecución?)"
				<< endl;
		cargado = false;
	}

	return cargado;
}

int tickPartida(partida p) {
	int numFilasMax, numColumnasMax;
	int utlFilas, utlColumnas;
	int x2, y2;
	bool salir = false;
	int exit;

	int x1, y1;
	int k,v;
	bool pareja;
	bool sinReplicas = false;

	bool tableroVacio = false;

	/*
	 * SECUENCIA DE INICIALIZACIÓN: CARGAR ENTORNO
	 */

	obtenerFilColMax(p.t, numFilasMax, numColumnasMax);
	obtenerFilCol(p.t, utlFilas, utlColumnas);

	entornoIniciar(numFilasMax, numColumnasMax);
	int i, j;
	bool rep = true;
	mostrarTablero(p.t);
	//Copiar datos del tablero a la matriz visible del entorno.
	for (i = 0; i < utlFilas; i++) {
		for (j = 0; j < utlColumnas; j++) {
			entornoPausa(0.075);
			entornoActivarNumero(i, j, obtenerNum(p.t, i, j)); //el número aparece en color negro
		}
	}

	entornoPonerPuntuacion(p.puntuacion, 0);

	while (!salir) {
		//Juego automático

		pareja = false;

		//Se recorre la matriz
		for (i = 0; (i < numFilasMax) && !pareja; i++) {
			for (j = 0; (j < numColumnasMax) && !pareja; j++) {
				//En cada celda nos detenemos a comprobar si forma pareja con las celdas de su misma fila y de filas inferiores
				for (k = i; (k < numFilasMax) && !pareja; k++) {
					for (v = 0; (v < numColumnasMax) && !pareja; v++) {
						//No se comprueba si es pareja consigo mismo
						if (!((i==k)&&(j==v))) {
							//No se comprueba si es pareja con celdas borradas o vacías
							if (!estaBorrada(p.t, i, j)&&!estaBorrada(p.t, k, v)){
								if (!estaVacia(p.t, i, j)&&!estaVacia(p.t, k, v)) {
									pareja = sonPareja(p.t, i, j, k, v);
								}
							}
						}
					}
				}
			}
		}

		if (pareja){
			x1 = i - 1;
			y1 = j - 1;
			x2 = k - 1;
			y2 = v - 1;
			pareja = sonPareja(p.t, x1, y1, x2, y2);
			if (pareja) {
				//Si forman pareja, borrar elementos, incrementar puntuación en 1.
				p.puntuacion++;
				entornoPonerPuntuacion(p.puntuacion, 1);
				borrarCelda(p.t, x1, y1);
				borrarCelda(p.t, x2, y2);
				if (x1 == x2) {
					if (esFilaBorrada(p.t, x1)) {
						borrarFila(p.t, x1);
						p.puntuacion += 10;
						entornoPonerPuntuacion(p.puntuacion, 10);
					}
				} else {
					if (x1 < x2) {
						if (esFilaBorrada(p.t, x2)) {
							borrarFila(p.t, x2);
							p.puntuacion += 10;
							entornoPonerPuntuacion(p.puntuacion, 10);
							if (esFilaBorrada(p.t, x1)) {
								borrarFila(p.t, x1);
								p.puntuacion += 10;
								entornoPonerPuntuacion(p.puntuacion, 10);
							}
						} else {
							if (esFilaBorrada(p.t, x1)) {
								borrarFila(p.t, x1);
								p.puntuacion += 10;
								entornoPonerPuntuacion(p.puntuacion, 10);
							}
						}
					} else {
						if (esFilaBorrada(p.t, x1)) {
							borrarFila(p.t, x1);
							p.puntuacion += 10;
							entornoPonerPuntuacion(p.puntuacion, 10);
							if (esFilaBorrada(p.t, x2)) {
								borrarFila(p.t, x2);
								p.puntuacion += 10;
								entornoPonerPuntuacion(p.puntuacion, 10);
							}
						} else {
							if (esFilaBorrada(p.t, x2)) {
								borrarFila(p.t, x2);
								p.puntuacion += 10;
								entornoPonerPuntuacion(p.puntuacion, 10);
							}
						}
					}
				}
				//código de actualización de entorno
				obtenerFilCol(p.t, utlFilas, utlColumnas);
				for (i = 0; i < numFilasMax; i++) {
					for (j = 0; j < numColumnasMax; j++) {
						entornoPonerVacio(i, j);
						if (!estaVacia(p.t, i, j)) {
							if (estaBorrada(p.t, i, j)) {
								entornoDesactivarNumero(i, j, obtenerNum(p.t, i, j));
							} else {
								entornoActivarNumero(i, j, obtenerNum(p.t, i, j)); //el número aparece en color negro
							}
						}
					}

				}
			}
		}
		else {
			//comprobamos que todavía quedan replicas disponibles
			if (p.replicas > 0) {
				//Replicamos el tablero
				rep = replicar(p.t);
				cout << "BOT: REPLICAR" << endl;
				//Actualizamos la matriz visible del entorno
				if (rep) { //Si replicar se ha podido completar...
					//Actualizamos los valores de las filas y columnas útiles
					obtenerFilCol(p.t, utlFilas, utlColumnas);
					//recorremos la matriz
					for (i = 0; i < utlFilas; i++) {
						for (j = 0; j < utlColumnas; j++) {
							//vaciamos todas las celdas
							entornoPonerVacio(i, j);
							//vamos comprobando cada celda del tablero, sus propiedades y las vamos escribiendo en la matriz visible del entorno
							if (!estaVacia(p.t, i, j)) {
								if (estaBorrada(p.t, i, j)) {
									entornoDesactivarNumero(i, j, obtenerNum(p.t, i, j));
								} else {
									entornoActivarNumero(i, j, obtenerNum(p.t, i, j)); //el número aparece en color negro
								}
							}
						}
					}
				} else {
					//Si replicar no se ha podido completar, enviar solicitud de cierre del juego
					salir = true;
				}
				p.replicas--;
			} else {
				//sin replicas, salir del juego
				sinReplicas = true;
				salir = true;
			}
		}


		mostrarTablero(p.t);


		//condición de victoria - Tablero vacio
		tableroVacio = true;
		for (i = 0; i < numFilasMax; i++) {
			for (j = 0; j < numColumnasMax; j++) {
				if (!(estaVacia(p.t, i, j))) {
					tableroVacio = false;
				}
			}
		}
		if (tableroVacio) {
			salir = true;
		}

	} //Fin de while
	//Códigos de salida
	if (!rep) {
		exit = 1;
	} else if (tableroVacio) {
		exit = 0;
	} else if (sinReplicas) {
		exit = 3;
	} else {
		exit = 2;
	}
	return exit;
}

void terminarPartida(int exit) {

	switch (exit) {
	case 0:
		entornoMostrarMensajeFin("¡¡ VICTORIA !!");
		break;
	case 1:
		entornoMostrarMensajeFin("No se puede replicar");
		break;
	case 2:
		entornoMostrarMensajeFin("GAME OVER");
		break;
	case 3:
		entornoMostrarMensajeFin("No te quedan replicas");
		break;
	}
	entornoPausa(0.5);
	entornoTerminar();
}
